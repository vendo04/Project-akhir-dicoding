import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dicoding/cart_model.dart';
import 'package:intl/intl.dart';

class FeaturedProduct extends StatelessWidget {
  final String id;
  final String category;
  final String name;
  final String description;
  final double price;
  //final String imageAsset;
  final String imageNetwork;

  const FeaturedProduct({
    super.key,
    required this.id,
    required this.category,
    required this.name,
    required this.description,
    required this.price,
    //required this.imageAsset,
    required this.imageNetwork,
  });

  @override
  Widget build(BuildContext context) {
    final currencyFormatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);
    return LayoutBuilder(
      builder: (context, constraints) {
        bool isMobile = constraints.maxWidth < 600;

        return Card(
          elevation: 4,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Image.network(
                  //  imageAsset,
                  imageNetwork,
                  width: double.infinity,
                  height: isMobile ? 150 : 200,
                  fit: BoxFit.cover,
                )
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(
                  category,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                child: Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold, 
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0), 
                child: Text(
                  currencyFormatter.format(price),
                  style: const TextStyle(
                    fontSize: 12.0,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      icon: Icon(Icons.add_shopping_cart),
                      onPressed: () {

                        Provider.of<CartProvider>(context, listen: false).addItem(
                          CartItem(
                            id: id,
                            //imageAsset: imageAsset,
                            imageNetwork: imageNetwork,
                            name: name,
                            price: price,
                          ),
                        );

                         ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('$name ditambahkan ke keranjang!'),
                            duration: Duration(seconds: 1),
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: Colors.green,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }
    );
  }
}

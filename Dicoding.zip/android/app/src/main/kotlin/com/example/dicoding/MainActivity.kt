package com.example.dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
